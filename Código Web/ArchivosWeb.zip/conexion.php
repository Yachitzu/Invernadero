<?php

$hostname ="mysql-108275-0.cloudclusters.net:19995";
$dbname= "Invernadero";
$username ="admin";
$password= "C9wwSb5b";
$conn = new mysqli($hostname,$username, $password, $dbname);
if($conn->connect_error) 
{
    echo "error en la conexion";
}else{
    echo "Conectado \n";
}
?>