<html>
<?php
include("conexion.php");
 
if($conn){
    echo "Conexion exitosa a la BD. \n";
    

if (isset($_POST['tempe'])){
         $tempe = $_POST['tempe'];
         $temperatura = intval($tempe);
    }

    if(isset($_POST['hume'])){
        $hume = $_POST['hume'];
        $humedad = intval($hume);
    }
    
    if (isset($_POST['disp'])){
        $dispositivo = $_POST['disp'];
    }
    
    
    echo "Recibido de: ".$dispositivo."\n";
    echo "Temperatura recibida: ".$temperatura."\n"; 
    echo "Humedad recibida: ".$humedad."\n";

    date_default_timezone_set('america/bogota');
    $fecha_actual = date("Y-m-d H:i:s");

   ?>

<a href="estado.php?tempe=<?php $tempe?>&hume=<?php $hume?>$disp=<?php $dispositivo?>"></a>
<?php
include "estado.php";
    
if (isset($_POST['est'])){
    $estado = $_POST['est'];
}

    $sqlInsert = "INSERT INTO Registros(NOM_INV , TEMP_INV, HUM_INV,FEC_HOR_INV, EST_INV) VALUES ('$dispositivo', '$temperatura', '$humedad', '$fecha_actual', '$estado')";
    $conn -> query($sqlInsert);
    
}else{
    echo "No se pudo conectar a la BD. \n";
}

?>

</html>

    
    
