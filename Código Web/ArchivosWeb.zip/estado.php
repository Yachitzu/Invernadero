<html>
<?php

include "conexion.php";

$sqlSelect = "SELECT TEMP_MIN_PLA, TEMP_MAX_PLA, HUM_MIN_PLA, HUM_MAX_PLA 
FROM plantas where NOM_PLA = 'Rosas'";

$respuesta = $conn-> query($sqlSelect);
$result = array();

if($respuesta -> num_rows > 0){
    while($filasCultivos = $respuesta->fetch_assoc()){
        array_push($result, $filasCultivos);
    }
}else{
    $result = "No hay datos en cultivos";
}

echo json_encode($result);

$tempMin = $result[0]['TEMP_MIN_PLA'];
$tempMax = $result[0]['TEMP_MAX_PLA'];
$humeMin = $result[0]['HUM_MIN_PLA'];
$humeMax = $result[0]['HUM_MAX_PLA'];

$temperaturaMin = intval($tempMin);
$temperaturaMax = intval($tempMax);
$humedadMin = intval($humeMin);
$humedadMax = intval($humeMax);

  if (isset($_POST['tempe'])){
         $tempe = $_POST['tempe'];
         $temperatura = intval($tempe);
    }

    if(isset($_POST['hume'])){
        $hume = $_POST['hume'];
        $humedad = intval($hume); 
    }
    
    if (isset($_POST['disp'])){
        $dispositivo = $_POST['disp'];
    }

    

if ($temperatura < $temperaturaMin or $temperatura > $temperaturaMax){
$estado = "Anormal";
    ?>
    <a href="correo.php?tempe=<?php $tempe?>&hume=<?php $hume?>$disp=<?php $dispositivo?>"></a>
    <a href="admin.php?est=<?php $estado?>"></a>

    <?php
    include "correo.php";

}else if ($humedad < $humedadMin or $humedad > $humedadMax){
    $estado = "Anormal";
    ?>
 <a href="correo.php?tempe=<?php $tempe?>&hume=<?php $hume?>$disp=<?php $dispositivo?>"></a>
 <a href="admin.php?est=<?php $estado?>"></a>

    <?php
    include "correo.php";
}else{
    $estado = "Normal";
    ?>
    <a href="admin.php?est=<?php $estado?>"></a>
    <?php
}
?>

</html>